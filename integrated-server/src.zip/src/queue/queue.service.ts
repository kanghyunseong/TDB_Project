import { Injectable, Logger, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { User } from '../users/entities/users.entity';
import { Repository } from 'typeorm';
import { Schedule, DayOfWeek, TimeOfDay } from '../schedule/entities/schedule.entity';
import { MachineSlot } from '../machine/entities/machine-slot.entity';
import { Machine } from '../machine/entities/machine.entity';
import { Medicine } from '../shared/entities/medicine.entity';

@Injectable()
export class QueueService {
  private readonly logger = new Logger(QueueService.name);

  constructor(
    @InjectRepository(User)
    private readonly userRepository: Repository<User>,
    @InjectRepository(Schedule)
    private readonly scheduleRepository: Repository<Schedule>,
    @InjectRepository(MachineSlot)
    private readonly machineSlotRepository: Repository<MachineSlot>,
    @InjectRepository(Machine)
    private readonly machineRepository: Repository<Machine>,
  ) {}

  async buildForDay(machineId: string, userId: number, day: string) {
    this.logger.log(`사용자 ${userId}의 ${day} 요일 배출 대기열 생성 중...`);

    const user = await this.userRepository.findOne({ where: { user_id: String(userId) } });
    if (!user) {
      throw new NotFoundException(`User with ID ${userId} not found.`);
    }

    const machine = await this.machineRepository.findOne({ where: { machine_id: machineId } });
    if (!machine) {
      throw new NotFoundException(`Machine with ID ${machineId} not found.`);
    }

    // 1. 해당 요일의 스케줄 조회
    const schedules = await this.scheduleRepository.find({
      where: {
        user_id: String(userId),
        day_of_week: day.toLowerCase() as DayOfWeek,
      },
      relations: ['medicine'], // medicine 정보도 함께 가져옴
    });

    // 2. 기기의 슬롯 정보 조회
    const machineSlots = await this.machineSlotRepository.find({
      where: { machine_id: machineId },
      relations: ['medicine'], // medicine 정보도 함께 가져옴
    });

    // medi_id를 slot_number로 매핑하기 위한 맵 생성
    const mediIdToSlotMap = new Map<string, number>();
    for (const slot of machineSlots) {
      if (slot.medi_id) {
        mediIdToSlotMap.set(slot.medi_id, slot.slot_number);
      }
    }

    // 3. 응답 형식에 맞게 데이터 구성
    const queue: { time: TimeOfDay; items: { slot: number; medi_id: string; count: number }[] }[] = [
      { time: 'morning', items: [] },
      { time: 'afternoon', items: [] },
      { time: 'evening', items: [] },
    ];

    for (const schedule of schedules) {
      const slotNumber = mediIdToSlotMap.get(schedule.medi_id);

      if (slotNumber !== undefined) {
        const timeSlot = queue.find((q) => q.time === schedule.time_of_day);
        if (timeSlot) {
          timeSlot.items.push({
            slot: slotNumber,
            medi_id: schedule.medi_id,
            count: schedule.dose,
          });
        }
      } else {
        this.logger.warn(`[QueueService] Medicine ID ${schedule.medi_id} for user ${userId} in schedule ${schedule.schedule_id} not found in machine slots for machine ${machineId}. Skipping.`);
      }
    }

    // 아이템이 없는 시간대는 제외
    const filteredQueue = queue.filter((timeSlot) => timeSlot.items.length > 0);

    return {
      status: 'ok',
      queue: filteredQueue,
    };
  }
}
