import { Controller, Post, Body, UseGuards, Logger, ValidationPipe } from '@nestjs/common';
import { QueueService } from './queue.service';
import { AccessTokenGuard } from '../auth/guard/bearer-token.guard';
import { ApiOperation, ApiTags, ApiBearerAuth } from '@nestjs/swagger';
import { BuildQueueDto } from './dto/build-queue.dto'; // Import the new DTO

// Utility functions for weekday inference
function inferWeekday(client_ts?: number, tz_offset_min?: number): string | undefined {
  if (!client_ts || typeof tz_offset_min === 'undefined') return;
  const ms = (client_ts * 1000) + (tz_offset_min * 60 * 1000);
  const d  = new Date(ms);
  return ['sun','mon','tue','wed','thu','fri','sat'][d.getUTCDay()];
}

function serverLocalWeekday(): string {
  return ['sun','mon','tue','wed','thu','fri','sat'][new Date().getDay()];
}

@ApiTags('디바이스 API')
@Controller('queue')
export class QueueController {
  private readonly logger = new Logger(QueueController.name);

  constructor(private readonly queueService: QueueService) {}

  @Post('build')
  @ApiOperation({ summary: '배출 대기열 생성 (요일 필터 포함)' })
  @ApiBearerAuth()
  async buildQueue(@Body(ValidationPipe) dto: BuildQueueDto) {
    this.logger.log(`[Device API] Queue Build 요청: user ${dto.user_id} for machine ${dto.machine_id}`);

    const day = dto.weekday?.toLowerCase()
      ?? inferWeekday(dto.client_ts, dto.tz_offset_min)
      ?? serverLocalWeekday();

    const queue = await this.queueService.buildForDay(dto.machine_id, dto.user_id, day);
    return { status: 'ok', queue };
  }
}
