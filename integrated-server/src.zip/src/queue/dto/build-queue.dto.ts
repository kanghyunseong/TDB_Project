import { IsInt, IsOptional, IsIn, IsString } from 'class-validator';

export class BuildQueueDto {
  @IsString()
  machine_id: string;

  @IsInt()
  user_id: number;

  @IsOptional()
  @IsIn(['mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun'], {
    message: 'weekday must be one of mon..sun',
  })
  weekday?: string;

  @IsOptional()
  @IsInt()
  client_ts?: number; // epoch seconds

  @IsOptional()
  @IsInt()
  tz_offset_min?: number; // e.g. +09:00 => 540
}
